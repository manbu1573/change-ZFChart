//
//  LineView.m
//  国通合众BIDemo
//
//  Created by 李荣建 on 16/8/22.
//  Copyright © 2016年 李荣建. All rights reserved.
//

#import "LineView.h"

@implementation LineView

-(void)drawRect:(CGRect)frame{
    self.backgroundColor = [[UIColor whiteColor]colorWithAlphaComponent:0.0f];
//            self.colorBackgroundView = [UIView new];
//            self.colorBackgroundView.frame = self.bounds;
//    
//            [self addSubview:self.colorBackgroundView];
    
            CAGradientLayer *gradientLayer = [[CAGradientLayer alloc] init];
    
            gradientLayer.colors = @[(__bridge id)[UIColor getColor:@"5effdb" alpha:0.0].CGColor,(__bridge id)[UIColor getColor:@"5effdb" alpha:0.3].CGColor];
    
            gradientLayer.startPoint = CGPointMake(1, 0);
    
            gradientLayer.endPoint = CGPointMake(1, 1);
    
            gradientLayer.frame = CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
    
            [self.layer addSublayer:gradientLayer];
}
@end
