//
//  LineView.h
//  国通合众BIDemo
//
//  Created by 李荣建 on 16/8/22.
//  Copyright © 2016年 李荣建. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LineView : UIView
@property(nonatomic,strong) UIView *colorBackgroundView;

@end
