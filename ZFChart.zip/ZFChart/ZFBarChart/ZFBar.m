//
//  ZFBar.m
//  ZFChart
//
//  Created by apple on 16/1/26.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ZFBar.h"
#import "ZFConst.h"
#import "NSString+Zirkfied.h"
//#import <QuartzCore/QuartzCore.h>

@interface ZFBar()

/** bar高度上限 */
@property (nonatomic, assign) CGFloat barHeightLimit;
/** 动画时间 */
@property (nonatomic, assign) CGFloat animationDuration;

@end

@implementation ZFBar

/**
 *  初始化默认变量
 */
- (void)commonInit{
    _barHeightLimit = self.frame.size.height;
    _percent = 0;
    _animationDuration = 0.5f;
    _isShadow = YES;
    _shadowColor = ZFLightGray;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
    }
    
    return self;
}

//添加label
-(void)layoutLabel{
    //label的中心点
    CGPoint label_center = CGPointMake(self.frame.size.width/2, _endYPos - 20);
    CGRect rect = CGRectMake(0,0, self.frame.size.width + self.frame.size.width * 0.5, 20);
    self.popoverLabel = [[ZFPopoverLabel alloc] initWithFrame:CGRectMake(0, 0, rect.size.width + 20, rect.size.height +5) direction:kAxisDirectionVertical];
    _popoverLabel.groupIndex = 0;
    _popoverLabel.textColor = ZFWhite;
    _popoverLabel.font = [UIFont systemFontOfSize:40];
    _popoverLabel.isShadow = YES;
    _popoverLabel.shadowColor = ZFBlack;
    _popoverLabel.arrowsOrientation = kPopoverLaberArrowsOrientationOnBelow;
    _popoverLabel.center = label_center;
    _popoverLabel.isAnimated = self.isAnimated;
    _popoverLabel.LabelBackgroundColor = ZFColor(64, 108, 230, 1);
    [_popoverLabel strokePath];
    [self addSubview:_popoverLabel];
    self.popoverLabel.hidden = YES;
}

-(UIBezierPath *)layoutBackgtound{
    CGFloat currentHeight = _barHeightLimit * self.percent;
    _endYPos = _barHeightLimit - currentHeight;
    //    UIBezierPath * bezier = [UIBezierPath bezierPathWithRect:CGRectMake(0, _endYPos, self.frame.size.width, currentHeight)];
    //创建path
    UIBezierPath *path = [UIBezierPath bezierPath];
//    // 添加圆到path
//    [path addArcWithCenter:CGPointMake(self.frame.size.width/2,  self.frame.size.width/2) radius:self.frame.size.width/2 startAngle:M_PI endAngle:0.0 clockwise:YES];
    // 设置描边宽度（为了让描边看上去更清楚）
//    [path setLineWidth:5.0];
//    path.lineCapStyle = kCGLineCapRound;
//    path.lineJoinStyle = kCGLineCapRound;
    // 起点
    [path moveToPoint:CGPointMake(0.0, _barHeightLimit )];
    // 绘制线条
    [path addLineToPoint:CGPointMake(self.frame.size.width, _barHeightLimit )];
    [path addLineToPoint:CGPointMake(self.frame.size.width, self.frame.size.width/2)];
    [path addLineToPoint:CGPointMake(0.0, self.frame.size.width/2)];
//    [path closePath];//第五条线通过调用closePath方法得到的
    //    //设置颜色（颜色设置也可以放在最上面，只要在绘制前都可以）
    return path;
}
-(UIBezierPath *)layoutRoundBackgtound{
    CGFloat currentHeight = _barHeightLimit * self.percent;
    _endYPos = _barHeightLimit - currentHeight;
    //    UIBezierPath * bezier = [UIBezierPath bezierPathWithRect:CGRectMake(0, _endYPos, self.frame.size.width, currentHeight)];
    //创建path
    UIBezierPath *path = [UIBezierPath bezierPath];
    // 添加圆到path
    [path addArcWithCenter:CGPointMake(self.frame.size.width/2,  self.frame.size.width/2) radius:self.frame.size.width/2 startAngle:M_PI endAngle:0.0 clockwise:YES];
    // 设置描边宽度（为了让描边看上去更清楚）
    //    [path setLineWidth:5.0];
    //    path.lineCapStyle = kCGLineCapRound;
    //    path.lineJoinStyle = kCGLineCapRound;
//    // 起点
//    [path moveToPoint:CGPointMake(0.0, _barHeightLimit )];
//    // 绘制线条
//    [path addLineToPoint:CGPointMake(self.frame.size.width, _barHeightLimit )];
//    [path addLineToPoint:CGPointMake(self.frame.size.width, self.frame.size.width/2)];
//    [path addLineToPoint:CGPointMake(0.0, self.frame.size.width/2)];
    //    [path closePath];//第五条线通过调用closePath方法得到的
    //    //设置颜色（颜色设置也可以放在最上面，只要在绘制前都可以）
    return path;
}

#pragma mark - bar

/**
 *  未填充
 *
 *  @return UIBezierPath
 */
- (UIBezierPath *)noFill{
    UIBezierPath * bezier = [UIBezierPath bezierPathWithRect:CGRectMake(0, _barHeightLimit, self.frame.size.width, 0)];
    return bezier;
}

/**
 *  填充
 *
 *  @return UIBezierPath
 */
- (UIBezierPath *)fill{
    CGFloat currentHeight = _barHeightLimit * self.percent;
    _endYPos = _barHeightLimit - currentHeight;
    //    UIBezierPath * bezier = [UIBezierPath bezierPathWithRect:CGRectMake(0, _endYPos, self.frame.size.width, currentHeight)];
    //创建path
    UIBezierPath *path = [UIBezierPath bezierPath];
    // 添加圆到path
//    [path addArcWithCenter:CGPointMake(self.frame.size.width/2, _endYPos + self.frame.size.width/2) radius:self.frame.size.width/2 startAngle:M_PI endAngle:0.0 clockwise:YES];
    // 设置描边宽度（为了让描边看上去更清楚）
    [path setLineWidth:5.0];
    path.lineCapStyle = kCGLineCapRound;
    path.lineJoinStyle = kCGLineCapRound;
    
    // 起点
    [path moveToPoint:CGPointMake(0.0, _barHeightLimit)];
    
    // 绘制线条
    [path addLineToPoint:CGPointMake(self.frame.size.width, _barHeightLimit)];
    [path addLineToPoint:CGPointMake(self.frame.size.width, _endYPos+ self.frame.size.width/2 -1)];
    
    [path addLineToPoint:CGPointMake(0.0, _endYPos+ self.frame.size.width/2 -1)];
//    [path closePath];//第五条线通过调用closePath方法得到的
    
    //    //设置颜色（颜色设置也可以放在最上面，只要在绘制前都可以）
    //    [[UIColor blueColor] setStroke];
    //    [[UIColor redColor] setFill];

    return path;
}
- (UIBezierPath *)roundfill{
    CGFloat currentHeight = _barHeightLimit * self.percent;
    _endYPos = _barHeightLimit - currentHeight;
    //    UIBezierPath * bezier = [UIBezierPath bezierPathWithRect:CGRectMake(0, _endYPos, self.frame.size.width, currentHeight)];
    //创建path
    UIBezierPath *path = [UIBezierPath bezierPath];
    // 添加圆到path
    [path addArcWithCenter:CGPointMake(self.frame.size.width/2, _endYPos + self.frame.size.width/2) radius:self.frame.size.width/2 startAngle:M_PI endAngle:0.0 clockwise:YES];
    // 设置描边宽度（为了让描边看上去更清楚）
    [path setLineWidth:5.0];
    path.lineCapStyle = kCGLineCapRound;
    path.lineJoinStyle = kCGLineCapRound;
    return path;
}

/**
 *  CAShapeLayer
 *
 *  @return CAShapeLayer
 */
- (CAShapeLayer *)shapeLayer{
    CAShapeLayer * layer = [CAShapeLayer layer];
    
    layer.fillColor = _barColor.CGColor;
    layer.lineCap = kCALineCapRound;
    layer.path = [self fill].CGPath;
    layer.opacity = _opacity;
    
    if (_isShadow) {
        layer.shadowOpacity = 0.5f;
        layer.shadowColor = _shadowColor.CGColor;
        layer.shadowOffset = CGSizeMake(2, 1);
    }
    
    if (_isAnimated) {
        CABasicAnimation * animation = [self animation];
        [layer addAnimation:animation forKey:nil];
    }
    
    return layer;
}
- (CAShapeLayer *)roundLayer{
    CAShapeLayer * layer = [CAShapeLayer layer];
    layer.fillColor = _barColor.CGColor;
    layer.lineCap = kCALineCapRound;
    layer.path = [self roundfill].CGPath;
    layer.opacity = _opacity;
    
//    if (_isShadow) {
//        layer.shadowOpacity = 0.5f;
//        layer.shadowColor = _shadowColor.CGColor;
//        layer.shadowOffset = CGSizeMake(2, 1);
//    }
//    
    if (_isAnimated) {
        CABasicAnimation * animation = [self roundanimation];
        [layer addAnimation:animation forKey:nil];
    }
    
    return layer;
}

-(CAShapeLayer *)backgroundlayer{
    CAShapeLayer * layer = [CAShapeLayer layer];
    layer.fillColor = kCOLOR(220, 220, 220).CGColor;
//    layer.strokeColor =kCOLOR(220, 220, 220).CGColor;
//    layer.lineWidth = 0.001;
    layer.lineCap = kCALineCapRound;
    layer.path = [self layoutBackgtound].CGPath;
    layer.opacity = _opacity;
    
    //    if (_isShadow) {
    //        layer.shadowOpacity = 0.5f;
    //        layer.shadowColor = _shadowColor.CGColor;
    //        layer.shadowOffset = CGSizeMake(2, 1);
    //    }
    //
    //    if (_isAnimated) {
    //        CABasicAnimation * animation = [self animation];
    //        [layer addAnimation:animation forKey:nil];
    //    }
    
    return layer;
}
-(CAShapeLayer *)backgroundRoundlayer{
    CAShapeLayer * layer = [CAShapeLayer layer];
    layer.fillColor = kCOLOR(220, 220, 220).CGColor;
//    layer.strokeColor =kCOLOR(220, 220, 220).CGColor;
//    layer.lineWidth = 0.001;
    layer.lineCap = kCALineCapRound;
    layer.path = [self layoutRoundBackgtound].CGPath;
    layer.opacity = _opacity;
    
    //    if (_isShadow) {
    //        layer.shadowOpacity = 0.5f;
    //        layer.shadowColor = _shadowColor.CGColor;
    //        layer.shadowOffset = CGSizeMake(2, 1);
    //    }
    //
    //    if (_isAnimated) {
    //        CABasicAnimation * animation = [self animation];
    //        [layer addAnimation:animation forKey:nil];
    //    }
    
    return layer;
}
#pragma mark - 动画

/**
 *  填充动画过程
 *
 *  @return CABasicAnimation
 */
- (CABasicAnimation *)animation{
    CABasicAnimation * fillAnimation = [CABasicAnimation animationWithKeyPath:@"path"];
    fillAnimation.duration = _animationDuration;
    fillAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    fillAnimation.fillMode = kCAFillModeForwards;
    fillAnimation.removedOnCompletion = NO;
    fillAnimation.fromValue = (__bridge id)([self noFill].CGPath);
    fillAnimation.toValue = (__bridge id)([self fill].CGPath);
    
    return fillAnimation;
}
- (CABasicAnimation *)roundanimation{
    CABasicAnimation * fillAnimation = [CABasicAnimation animationWithKeyPath:@"path"];
    fillAnimation.duration = _animationDuration;
    fillAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    fillAnimation.fillMode = kCAFillModeForwards;
    fillAnimation.removedOnCompletion = NO;
    fillAnimation.fromValue = (__bridge id)([self noFill].CGPath);
    fillAnimation.toValue = (__bridge id)([self roundfill].CGPath);
    
    return fillAnimation;
}
/**
 *  清除之前所有subLayers
 */
- (void)removeAllLayer{
    NSArray * sublayers = [NSArray arrayWithArray:self.layer.sublayers];
    for (CALayer * layer in sublayers) {
        [layer removeAllAnimations];
        [layer removeFromSuperlayer];
    }
}

#pragma mark - public method

/**
 *  重绘
 */
- (void)strokePath{
    [self removeAllLayer];
    [self.layer addSublayer:[self backgroundlayer]];
    [self.layer addSublayer:[self backgroundRoundlayer]];
    [self.layer addSublayer:[self shapeLayer]];
    [self.layer addSublayer:[self roundLayer]];
    [self layoutLabel];
}

@end
